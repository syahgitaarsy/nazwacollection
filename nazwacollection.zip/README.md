# online_shop_ongkir
LITTLE ONLINE SHOP WITH PERHITUNGAN ONGKIR WITH PHP 7 & MYSQLi

PANDUAN INSTALASI SOURCE CODE

1. Buka localhost/phpmyadmin pada web browser.
2. Buat database baru dengan nama 'project_tokoonline'.
3. Import file 'project_tokoonline.sql' ke database 'project_tokoonline' yang sudah dibuat.
4. Copy folder 'project_tokoonline' ke folder htdocs. 
	Letak folder htdocs XAMPP windows ada di C://XAMPP/htdocs
5. Akses toko online dengan alamat 'localhost/online-shop' pada web browser.
6. Selesai.


###############################################################

LOGIN ADMIN

username : admin
password : admin

